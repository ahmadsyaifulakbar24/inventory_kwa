	<script src="{{asset('assets/vendors/jquery/jquery.min.js')}}"></script>
	<script src="{{asset('assets/vendors/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
	<script src="{{asset('assets/js/main.js')}}"></script>
	<script>const root = '{{Request::root()}}/'</script>
	<script>const api_url = 'http://api.inventory.lekarlwig.com/'</script>