	<script src="<?php echo e(asset('assets/vendors/jquery/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
	<script>const root = '<?php echo e(Request::root()); ?>/'</script>
	<script>const api_url = 'http://api.inventory.lekarlwig.com/'</script><?php /**PATH D:\xampp\htdocs\inventory_kwa\inventory_kwa\resources\views/layouts/partials/script.blade.php ENDPATH**/ ?>